
import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const generateAssistantResponse = async (
  userMessage: string, 
  history: { role: string; text: string }[]
): Promise<string> => {
  if (!apiKey) {
    return "I'm sorry, the AI service is currently unavailable. Please contact us directly via email at ap.tex.bd95@gmail.com";
  }

  try {
    const systemInstruction = `
      You are the Virtual Assistant for AP Tex BD, a leading Textile Manufacturer and Buying House in Bangladesh.
      
      Your goal is to assist international buyers (B2B) with sourcing inquiries regarding Denim, Knitwear, and Woven garments.
      
      Key Information about AP Tex BD:
      - Business Type: Manufacturer & Buying House (Hybrid).
      - Core Strength: Own Factory with 250 skilled workers + In-house Denim Washing Facility.
      - Production Capacity: 150,000 pcs per month (100k Denim/Woven + 50k Knits).
      - Minimum Order Quantity (MOQ): From 200 pcs per style.
      - Core Products: Denim Jackets, Denim Jeans, Denim Shirts, Knit T-Shirts, Polos, Woven Casuals.
      - Lead Times: Samples (5-7 days), Bulk (45-75 days).
      - Quality: AQL 1.5 to 2.5 standard. Strict QC from fabric to packing.
      - Contact: WhatsApp +8801954301501, Email ap.tex.bd95@gmail.com
      
      Guidelines:
      - Be professional, polite, and concise. 
      - If asked for price, explain that pricing depends on fabric, quantity, and design, and ask them to use the "Get Quote" form or contact via WhatsApp.
      - Highlight the "In-house Denim Washing" as a key advantage for denim inquiries.
      - Emphasize that we manufacture according to the buyer's specific design and fabric choice.
    `;

    const model = 'gemini-2.5-flash';
    
    const response = await ai.models.generateContent({
      model,
      contents: [
        { role: 'user', parts: [{ text: userMessage }] }
      ],
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    return response.text || "I apologize, I didn't catch that. Could you please rephrase?";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I am having trouble connecting to the server. Please email us directly at ap.tex.bd95@gmail.com";
  }
};

export const generateDesignImage = async (
  prompt: string,
  size: '1K' | '2K' | '4K' = '1K'
): Promise<string | null> => {
  if (!apiKey) {
    console.error("API Key missing");
    return null;
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1",
          imageSize: size
        },
      },
    });

    // Extract image from response
    if (response.candidates?.[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const base64EncodeString = part.inlineData.data;
          return `data:image/png;base64,${base64EncodeString}`;
        }
      }
    }
    return null;
  } catch (error) {
    console.error("Gemini Image Gen Error:", error);
    throw error;
  }
};
